import { atom } from "recoil";

export const profile = atom({
    key: "profile",
    default: {}
})